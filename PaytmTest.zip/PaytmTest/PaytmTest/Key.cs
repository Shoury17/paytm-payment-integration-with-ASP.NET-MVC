﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PaytmTest
{
    public class Key
    {
        public static string merchantKey = "x3ueX@w61e3aaWLt";
        public static string merchantId = "TechCr78685823786067";
    }
}